The sample code demonstrates how to list all files under a directory and obtain file types.
