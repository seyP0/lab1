The sample code demonstrates how to use pointers to access a C structure.
