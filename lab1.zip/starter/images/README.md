The directory contains some PNG images.

* WEEF\_1.png: a complete image.
* uweng.png: a complete image.
* red-green-16x16.png: an image containing one red bar on the left and one green bar on the right.
* cropped: cropped images by splitting the WEEF\_1.png from top to bottom (i.e. vertically). Each cropped image is a horizontal strip of the original image.
* uweng\_cropped: cropped images by splitting the uweng.png from top to bottom (i.e. vertically). Each cropped image is a horizontal strip of the original image.
