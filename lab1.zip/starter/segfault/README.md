The sample code demonstrates a segmentation fault. 
