This is the repository of the first assignment of the ECE252 course.
Expected repository structure:

```username-lab1
├── starter
├── Makefile
├── README.md
├── src
├── include
├── directory1 (optional)

```